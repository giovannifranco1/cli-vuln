# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cli_vuln', 'cli_vuln.common', 'cli_vuln.vulnerabilities']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.9.0,<0.10.0']

entry_points = \
{'console_scripts': ['cli_start = cli_vuln.main:app']}

setup_kwargs = {
    'name': 'cli-vuln',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'giovanni.franco',
    'author_email': 'giovanni.franco@nanoincub.com.br',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
