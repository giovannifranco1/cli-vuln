# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cli_vuln', 'cli_vuln.common', 'cli_vuln.core', 'cli_vuln.vulnerabilities']

package_data = \
{'': ['*'], 'cli_vuln': ['out/*']}

install_requires = \
['requests>=2.31.0,<3.0.0',
 'termcolor>=2.3.0,<3.0.0',
 'typer[all]>=0.9.0,<0.10.0']

entry_points = \
{'console_scripts': ['cli-start = cli_vuln.main:app']}

setup_kwargs = {
    'name': 'cli-vuln',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Vuln\n\n![Python Version](https://img.shields.io/badge/Python-^3.8.0-brightgreen) ![Poetry(https://getcomposer.org/doc/00-intro.md#installation-linux-unix-macos) ](https://img.shields.io/badge/Poetry-^1.2.0-brightgreen) ![by Giovanni](https://img.shields.io/badge/%20by-Giovannni-informational?color=ee564b)\n\n[🛠 Ferramentas](#ferramentas) | [⚙ Instalação](#instalação)\n\n---\n\n## Ferramentas\n\n- Requisitos\n  - [Python](https://www.python.org/)\n  - [Poetry](https://python-poetry.org/)\n  - [Git](https://git-scm.com/downloads)\n\n- Recomendados\n  - [Docker](https://www.docker.com/)\n  - [Container MySQL](https://gitlab.com/nanoincub/docker/docker-mysql)\n  - [Container PHP & Apache](https://gitlab.com/nanoincub/docker/docker-php-apache)\n\n---\n\n## Instalação\n\n### Copie o .env.example para .env\n```bash\n  cp .env.example .env\n```\n\n### Deploy de todos os projetos\n```bash\n  ./start.sh --deploy --migrate_fresh\n```\n\n### Deploy de um projeto específico\n```bash\n  ./build.sh --projeto caule-painel-empresa\n```\n\n### Entrar em um container específico\n```bash\n  ./d_enter.sh\n```\n\n# Docker\n\n## Ferramentas\n\n- Docker\n  - Apache (apache)\n  - Painel Empresa (caule-painel-empresa)\n  - Painel Admin (php-painel-adm)\n  - API (caule-api)\n\n## Configuração Hosts\n\n```\n127.0.0.1 caule.local admin.caule.local nanoincub.caule.local nanoincub.caule.local api.caule.local nanoincub.api.caule.local  s3.caule.local s3-manager.caule.local  mailhog.caule.local redisinsight.caule.local phpmyadmin.caule.local\n```\n\n################################################################\n\n## Comandos básicos\n\nDeploy de todos os projetos\n```\n./start.sh --deploy --migrate\n```\n\nSubir servicos\n```\n./start.sh\n```\n\nPausar servicos\n```\n./stop.sh\n```\n\nResetar banco de dados e rodar as migrate\n```\n./start.sh --migrate\n```\n\n################################################################\n\n## Deploy das aplicações\n\nPainel Empresa\n./deploy --project caule-painel-empresa\n\nPainel Adm\nPainel Empresa\n./deploy --project caule-painel-admin\n\nAPI\n./deploy --project caule-api\n\n################################################################\n\n',
    'author': 'giovanni.franco',
    'author_email': 'giovanni.franco@nanoincub.com.br',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
