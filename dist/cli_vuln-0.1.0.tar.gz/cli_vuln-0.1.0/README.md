# Vuln

![Python Version](https://img.shields.io/badge/Python-^3.8.0-brightgreen) ![Poetry(https://getcomposer.org/doc/00-intro.md#installation-linux-unix-macos) ](https://img.shields.io/badge/Poetry-^1.2.0-brightgreen) ![by Giovanni](https://img.shields.io/badge/%20by-Giovannni-informational?color=ee564b)

[🛠 Ferramentas](#ferramentas) | [⚙ Instalação](#instalação)

---

## Ferramentas

- Requisitos
  - [Python](https://www.python.org/)
  - [Poetry](https://python-poetry.org/)
  - [Git](https://git-scm.com/downloads)

- Recomendados
  - [Docker](https://www.docker.com/)
  - [Container MySQL](https://gitlab.com/nanoincub/docker/docker-mysql)
  - [Container PHP & Apache](https://gitlab.com/nanoincub/docker/docker-php-apache)

---

## Instalação

### Copie o .env.example para .env
```bash
  cp .env.example .env
```

### Deploy de todos os projetos
```bash
  ./start.sh --deploy --migrate_fresh
```

### Deploy de um projeto específico
```bash
  ./build.sh --projeto caule-painel-empresa
```

### Entrar em um container específico
```bash
  ./d_enter.sh
```

# Docker

## Ferramentas

- Docker
  - Apache (apache)
  - Painel Empresa (caule-painel-empresa)
  - Painel Admin (php-painel-adm)
  - API (caule-api)

## Configuração Hosts

```
127.0.0.1 caule.local admin.caule.local nanoincub.caule.local nanoincub.caule.local api.caule.local nanoincub.api.caule.local  s3.caule.local s3-manager.caule.local  mailhog.caule.local redisinsight.caule.local phpmyadmin.caule.local
```

################################################################

## Comandos básicos

Deploy de todos os projetos
```
./start.sh --deploy --migrate
```

Subir servicos
```
./start.sh
```

Pausar servicos
```
./stop.sh
```

Resetar banco de dados e rodar as migrate
```
./start.sh --migrate
```

################################################################

## Deploy das aplicações

Painel Empresa
./deploy --project caule-painel-empresa

Painel Adm
Painel Empresa
./deploy --project caule-painel-admin

API
./deploy --project caule-api

################################################################

