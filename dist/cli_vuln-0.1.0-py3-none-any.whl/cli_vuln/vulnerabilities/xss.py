import re
from common.abc import Vulnerability


class Xss(Vulnerability):
    name = "CROSS-SITE SCRIPTING (XSS)"
    keyname = "xss"

    def __init__(self, file_path):
        super().__init__(file_path)
        print("construtor")

    def find(self):
        print("find...")
        return self._find(r"[a-z]", False)
