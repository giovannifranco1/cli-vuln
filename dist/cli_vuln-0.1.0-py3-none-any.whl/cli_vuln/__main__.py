import sys
import os
import typer
import time
from vulnerabilities.xss import Xss
from rich.progress import track
from typing import Optional
from pathlib import Path

app = typer.Typer()


@app.command()
def main(name: str = typer.prompt("Digite o seu nome: ")):
    print(f"Hello {name}")
    typer.echo("opa")
    total = 0
    for value in track(range(100), description="Processing..."):
        # Fake processing time
        time.sleep(0.01)
        total += 1
    print(f"Processed {total} things.")


@app.command()
def xss(filename: Path):
    typer.echo("xss")
    typer.echo(filename.is_file())
    typer.echo(filename.exists())
    if filename.is_file():
        typer.echo("é um arquivo")


@app.command()
def verificar_arquivo(caminho: str):
    # Crie um objeto Path com o caminho especificado
    path = Path(caminho)

    # Use o método is_file() para verificar se o caminho aponta para um arquivo existente
    if path.is_file() and path.suffix.lower() == ".php":
        with open(path, "r") as arquivo_php:
            # Leia o conteúdo do arquivo
            conteudo = arquivo_php.read()

            vuln_xss = Xss(caminho)
            print(vuln_xss.find())

            # Imprima o conteúdo no console
            typer.echo(f"Conteúdo do arquivo PHP {path}:\n")
            typer.echo(conteudo)
    else:
        typer.echo(f"O arquivo {path} não existe ou não é um arquivo PHP.")


if __name__ == "__main__":
    print("main")
    app()
